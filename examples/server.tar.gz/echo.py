def f(event):
    return event
