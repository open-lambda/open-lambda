def f(event):
    return 'hello'
