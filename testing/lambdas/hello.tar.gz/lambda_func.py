def handler(db_conn, event):
    return 'hello'
