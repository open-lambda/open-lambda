def handler(db_conn, event):
    return event
