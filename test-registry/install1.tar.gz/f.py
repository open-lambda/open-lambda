import requests
import urllib3

def f(event):
    return 'imported'
