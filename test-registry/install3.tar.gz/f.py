import requests
import urllib3
import simplejson

def f(event):
    return 'imported'
